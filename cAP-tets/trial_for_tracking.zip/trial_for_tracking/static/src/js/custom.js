// odoo.define('wt_medquest_website.custom', function (require) {
// 'use strict';

// var publicWidget = require('web.public.widget');
// var core = require('web.core');
// var _t = core._t;

// 	$(document).ready(function(){

// 		 if($('#wrap').hasClass('home_page_main_cl')){
// 			$('#myModal').modal('show');
// 		}

// 		$(".overlay_btn").click(function(){
//             $('#myModal').removeClass('show');
//             $(".modal_home_main_cl").css({ 'display' : ''});
//         });

//         if($("li").hasClass('o_extra_menu_items')){
//         	console.log("#########################")
// 			$('.o_extra_menu_items').remove();
// 		}
// 		var myVar = $("#top_menu").find('.o_extra_menu_items');
// 		debugger;
// 		console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@",myVar)
// 	});
	
// });